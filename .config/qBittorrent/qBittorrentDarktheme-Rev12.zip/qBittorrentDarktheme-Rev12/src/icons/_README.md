"icons folder" is
from https://github.com/qbittorrent/qBittorrent/tree/master/src/icons